export const ADD_FETCH="ADD_FETCH"
export const Add_fetch=(payload)=>({type:ADD_FETCH,payload})