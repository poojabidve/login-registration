
import React from "react";


export const Footer = ()=>{

  
    return(
        <div class="card-footer bg-transparent text-dark">
       <p class="font-italic" id="footer">
       <div class="footer-copyright text-center py-3">© 2022 Copyright:
    <a href="/"> Heartly Lab.com</a>
  </div>

        </p> 
      
      </div>
    )
}